import sys
import os

app_path = '/home/rolexeys/bloodislife.rolexey.shop'
venv_path = '/home/rolexeys/virtualenv/bloodislife.rolexey.shop/3.10'

os.chdir(app_path)
sys.path.insert(0, app_path)
sys.path.insert(0, os.path.join(venv_path, 'lib/python3.10/site-packages'))

try:
    from app import application as app
    application = app
except Exception as e:
    with open(os.path.join(app_path, 'import_error.log'), 'w') as f:
        f.write(f"Import Error: {str(e)}\n")
    raise