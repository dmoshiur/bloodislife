import os
from datetime import datetime, timedelta
from flask import Flask, render_template, request, redirect, url_for, flash, send_from_directory, jsonify, abort
from flask_sqlalchemy import SQLAlchemy
from flask_login import LoginManager, UserMixin, login_user, login_required, logout_user, current_user
from werkzeug.security import generate_password_hash, check_password_hash
from werkzeug.utils import secure_filename
from functools import wraps

# Initialize Flask App
app = Flask(__name__)

# Configuration
app.config['SECRET_KEY'] = os.environ.get('SECRET_KEY', 'blood-donation-secret-key-2026-badhan-style')
basedir = os.path.abspath(os.path.dirname(__file__))
app.config['SQLALCHEMY_DATABASE_URI'] = 'sqlite:///' + os.path.join(basedir, 'blood_network.db')
app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False
app.config['UPLOAD_FOLDER'] = os.path.join(basedir, 'uploads')
app.config['MAX_CONTENT_LENGTH'] = 16 * 1024 * 1024

os.makedirs(app.config['UPLOAD_FOLDER'], exist_ok=True)

db = SQLAlchemy(app)
login_manager = LoginManager()
login_manager.init_app(app)
login_manager.login_view = 'login'

# Database Models
class User(UserMixin, db.Model):
    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(100), nullable=False)
    email = db.Column(db.String(120), unique=True, nullable=False, index=True)
    phone = db.Column(db.String(20), nullable=False)
    address_holding = db.Column(db.String(100))
    division = db.Column(db.String(50))
    district = db.Column(db.String(50), index=True)
    upazila = db.Column(db.String(50), index=True)
    union = db.Column(db.String(50))
    blood_group = db.Column(db.String(5), index=True)
    image_file = db.Column(db.String(100), nullable=False, default='default.jpg')
    password_hash = db.Column(db.String(128))
    role = db.Column(db.String(20), default='Both')  # Donor, Recipient, Both, Volunteer
    can_donate = db.Column(db.Boolean, default=False)  # Default False, enable after 18+ verification
    last_donation = db.Column(db.Date, nullable=True)
    is_admin = db.Column(db.Boolean, default=False, index=True)
    is_super_admin = db.Column(db.Boolean, default=False)
    is_verified = db.Column(db.Boolean, default=False)  # Admin verification for donors
    created_at = db.Column(db.DateTime, default=datetime.utcnow, index=True)
    
    # Age & Birth Info
    age = db.Column(db.Integer, nullable=True)
    date_of_birth = db.Column(db.Date, nullable=True)
    birth_certificate_number = db.Column(db.String(50), nullable=True)  # Optional
    
    # Relationships
    sent_messages = db.relationship('Message', foreign_keys='Message.sender_id', backref='sender', lazy='dynamic')
    received_messages = db.relationship('Message', foreign_keys='Message.recipient_id', backref='recipient', lazy='dynamic')
    blood_requests = db.relationship('BloodRequest', backref='requester', lazy='dynamic')

    def set_password(self, password):
        self.password_hash = generate_password_hash(password, method='pbkdf2:sha256')

    def check_password(self, password):
        return check_password_hash(self.password_hash, password)
    
    def calculate_age(self):
        if self.date_of_birth:
            today = datetime.today()
            age = today.year - self.date_of_birth.year - ((today.month, today.day) < (self.date_of_birth.month, self.date_of_birth.day))
            return age
        return None
    
    def can_donate_blood(self):
        """Check if user is eligible to donate (18+ years, verified, available)"""
        if self.age and self.age >= 18 and self.is_verified and self.can_donate:
            return True
        return False

class BloodRequest(db.Model):
    """Blood request model for urgent and regular requests"""
    id = db.Column(db.Integer, primary_key=True)
    requester_id = db.Column(db.Integer, db.ForeignKey('user.id'), nullable=True)  # NULL = guest request
    patient_name = db.Column(db.String(100), nullable=False)
    patient_relation = db.Column(db.String(50))  # Self, Father, Mother, etc.
    blood_group = db.Column(db.String(5), nullable=False, index=True)
    quantity = db.Column(db.String(20), default='1 unit')
    hospital_name = db.Column(db.String(150), nullable=False)
    hospital_address = db.Column(db.Text, nullable=False)
    contact_person = db.Column(db.String(100), nullable=False)
    contact_phone = db.Column(db.String(20), nullable=False)
    contact_email = db.Column(db.String(120))
    
    # Urgent Request Fields
    is_urgent = db.Column(db.Boolean, default=False, index=True)
    urgent_reason = db.Column(db.Text)  # Accident, Surgery, etc.
    needed_by = db.Column(db.DateTime, nullable=False)  # Deadline for blood
    is_fulfilled = db.Column(db.Boolean, default=False, index=True)
    fulfilled_at = db.Column(db.DateTime, nullable=True)
    fulfilled_by = db.Column(db.Integer, db.ForeignKey('user.id'), nullable=True)
    
    location_division = db.Column(db.String(50), index=True)
    location_district = db.Column(db.String(50), index=True)
    location_upazila = db.Column(db.String(50), index=True)
    
    additional_info = db.Column(db.Text)
    status = db.Column(db.String(20), default='open')  # open, in-progress, fulfilled, cancelled
    created_at = db.Column(db.DateTime, default=datetime.utcnow, index=True)
    updated_at = db.Column(db.DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)

class Message(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    sender_id = db.Column(db.Integer, db.ForeignKey('user.id'), nullable=False)
    recipient_id = db.Column(db.Integer, db.ForeignKey('user.id'), nullable=True)
    subject = db.Column(db.String(200), nullable=False)
    content = db.Column(db.Text, nullable=False)
    is_read = db.Column(db.Boolean, default=False)
    is_admin_message = db.Column(db.Boolean, default=False)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    replied_to = db.Column(db.Integer, db.ForeignKey('message.id'), nullable=True)

class AntiDInfo(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    title = db.Column(db.String(200), nullable=False)
    description = db.Column(db.Text, nullable=False)
    timing = db.Column(db.String(500), nullable=False)
    dosage = db.Column(db.String(200), nullable=False)
    image_file = db.Column(db.String(100), default='antid_default.jpg')
    created_at = db.Column(db.DateTime, default=datetime.utcnow)

class SiteNotice(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    content = db.Column(db.String(500), nullable=False)
    active = db.Column(db.Boolean, default=True)
    updated_at = db.Column(db.DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)

class Resource(db.Model):
    """Educational resources like Badhan.org"""
    id = db.Column(db.Integer, primary_key=True)
    title = db.Column(db.String(200), nullable=False)
    category = db.Column(db.String(50))  # Donation, Health, First-Aid, etc.
    content = db.Column(db.Text, nullable=False)
    image_file = db.Column(db.String(100))
    is_featured = db.Column(db.Boolean, default=False)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)

@login_manager.user_loader
def load_user(user_id):
    try:
        return User.query.get(int(user_id))
    except:
        return None

def allowed_file(filename):
    return '.' in filename and filename.rsplit('.', 1)[1].lower() in {'png', 'jpg', 'jpeg', 'gif'}

def admin_required(f):
    @wraps(f)
    def decorated_function(*args, **kwargs):
        if not current_user.is_authenticated or not current_user.is_admin:
            flash("You do not have permission to access this page.", "danger")
            return redirect(url_for('home'))
        return f(*args, **kwargs)
    return decorated_function

@app.errorhandler(404)
def not_found_error(error):
    return render_template('404.html'), 404

@app.errorhandler(500)
def internal_error(error):
    db.session.rollback()
    return render_template('500.html'), 500

@app.errorhandler(413)
def file_too_large(error):
    flash("File size exceeds 16MB limit.", "danger")
    return redirect(request.referrer or url_for('home'))

# ==================== ROUTES ====================

@app.route('/')
def home():
    try:
        notice = SiteNotice.query.filter_by(active=True).first()
        total_donors = User.query.filter_by(can_donate=True, is_verified=True).count()
        urgent_requests = BloodRequest.query.filter_by(is_urgent=True, is_fulfilled=False).count()
        recent_donors = User.query.filter_by(can_donate=True, is_verified=True).order_by(User.created_at.desc()).limit(6).all()
        recent_requests = BloodRequest.query.filter_by(is_fulfilled=False).order_by(BloodRequest.created_at.desc()).limit(5).all()
    except Exception as e:
        app.logger.error(f"Home error: {e}")
        notice = None
        total_donors = 0
        urgent_requests = 0
        recent_donors = []
        recent_requests = []
    
    return render_template('home.html', 
                          notice=notice, 
                          total_donors=total_donors, 
                          urgent_requests=urgent_requests,
                          recent_donors=recent_donors,
                          recent_requests=recent_requests)

@app.route('/uploads/<filename>')
def uploaded_file(filename):
    return send_from_directory(app.config['UPLOAD_FOLDER'], filename)

# ==================== BLOOD REQUEST ROUTES ====================

@app.route('/request-blood', methods=['GET', 'POST'])
def request_blood():
    """Any person can request blood (logged in or guest)"""
    if request.method == 'POST':
        try:
            # Get form data
            patient_name = request.form.get('patient_name')
            blood_group = request.form.get('blood_group')
            hospital_name = request.form.get('hospital_name')
            hospital_address = request.form.get('hospital_address')
            contact_person = request.form.get('contact_person')
            contact_phone = request.form.get('contact_phone')
            contact_email = request.form.get('contact_email')
            needed_by = request.form.get('needed_by')
            is_urgent = 'is_urgent' in request.form
            urgent_reason = request.form.get('urgent_reason') if is_urgent else None
            location_division = request.form.get('division')
            location_district = request.form.get('district')
            location_upazila = request.form.get('upazila')
            additional_info = request.form.get('additional_info')
            patient_relation = request.form.get('patient_relation', 'Self')
            quantity = request.form.get('quantity', '1 unit')
            
            # Parse needed_by datetime
            needed_by_dt = datetime.strptime(needed_by, '%Y-%m-%dT%H:%M')
            
            # Create request
            blood_request = BloodRequest(
                requester_id=current_user.id if current_user.is_authenticated else None,
                patient_name=patient_name,
                patient_relation=patient_relation,
                blood_group=blood_group,
                quantity=quantity,
                hospital_name=hospital_name,
                hospital_address=hospital_address,
                contact_person=contact_person,
                contact_phone=contact_phone,
                contact_email=contact_email,
                is_urgent=is_urgent,
                urgent_reason=urgent_reason,
                needed_by=needed_by_dt,
                location_division=location_division,
                location_district=location_district,
                location_upazila=location_upazila,
                additional_info=additional_info
            )
            
            db.session.add(blood_request)
            db.session.commit()
            
            if is_urgent:
                flash('🚨 URGENT blood request submitted! Donors in your area will be notified.', 'warning')
            else:
                flash('Blood request submitted successfully. Thank you!', 'success')
            
            return redirect(url_for('blood_requests'))
            
        except Exception as e:
            db.session.rollback()
            app.logger.error(f"Blood request error: {e}")
            flash('Failed to submit request. Please try again.', 'danger')
            return redirect(url_for('request_blood'))
    
    return render_template('request_blood.html')

@app.route('/blood-requests')
def blood_requests():
    """List all blood requests with filters"""
    try:
        bg_filter = request.args.get('bg')
        dist_filter = request.args.get('dist')
        urgent_filter = request.args.get('urgent')
        
        query = BloodRequest.query.filter_by(is_fulfilled=False)
        
        if bg_filter:
            query = query.filter_by(blood_group=bg_filter)
        if dist_filter:
            query = query.filter(BloodRequest.location_district.ilike(f'%{dist_filter}%'))
        if urgent_filter == 'true':
            query = query.filter_by(is_urgent=True)
        
        # Sort: urgent first, then by needed_by
        requests = query.order_by(
            BloodRequest.is_urgent.desc(),
            BloodRequest.needed_by.asc()
        ).all()
        
        return render_template('blood_requests.html', requests=requests)
    except Exception as e:
        app.logger.error(f"Blood requests error: {e}")
        return render_template('blood_requests.html', requests=[])

@app.route('/blood-request/<int:request_id>')
def view_blood_request(request_id):
    """View single blood request details"""
    try:
        blood_request = BloodRequest.query.get_or_404(request_id)
        return render_template('view_blood_request.html', request=blood_request)
    except:
        abort(404)

@app.route('/blood-request/<int:request_id>/fulfill', methods=['POST'])
@login_required
def fulfill_blood_request(request_id):
    """Mark a blood request as fulfilled"""
    try:
        blood_request = BloodRequest.query.get_or_404(request_id)
        
        if blood_request.is_fulfilled:
            flash('This request is already fulfilled.', 'info')
            return redirect(url_for('view_blood_request', request_id=request_id))
        
        # Mark as fulfilled
        blood_request.is_fulfilled = True
        blood_request.fulfilled_at = datetime.utcnow()
        blood_request.fulfilled_by = current_user.id
        blood_request.status = 'fulfilled'
        
        db.session.commit()
        
        # Auto-remove from urgent list if it was urgent
        if blood_request.is_urgent:
            flash('✅ Urgent request marked as fulfilled. Thank you for donating!', 'success')
        else:
            flash('Blood request marked as fulfilled. Thank you!', 'success')
        
        return redirect(url_for('blood_requests'))
    except Exception as e:
        db.session.rollback()
        app.logger.error(f"Fulfill request error: {e}")
        flash('Failed to update request. Please try again.', 'danger')
        return redirect(url_for('view_blood_request', request_id=request_id))

@app.route('/blood-request/<int:request_id>/cancel', methods=['POST'])
def cancel_blood_request(request_id):
    """Cancel a blood request (only by requester or admin)"""
    try:
        blood_request = BloodRequest.query.get_or_404(request_id)
        
        # Check permission
        if current_user.is_authenticated:
            if blood_request.requester_id == current_user.id or current_user.is_admin:
                blood_request.status = 'cancelled'
                blood_request.is_fulfilled = True  # Remove from active list
                db.session.commit()
                flash('Blood request cancelled.', 'info')
            else:
                flash('You do not have permission to cancel this request.', 'danger')
        else:
            flash('Please login to manage requests.', 'warning')
        
        return redirect(url_for('blood_requests'))
    except Exception as e:
        db.session.rollback()
        app.logger.error(f"Cancel request error: {e}")
        flash('Failed to cancel request.', 'danger')
        return redirect(url_for('blood_requests'))

# ==================== DONOR ROUTES ====================

@app.route('/donors')
def donors():
    """Find eligible donors (18+, verified, available)"""
    try:
        bg = request.args.get('bg')
        dist = request.args.get('dist')
        upa = request.args.get('upa')
        age_min = request.args.get('age_min', type=int)
        
        # Only show verified donors who are 18+ and available
        query = User.query.filter(
            User.can_donate == True,
            User.is_verified == True,
            User.age >= 18
        )
        
        if bg:
            query = query.filter_by(blood_group=bg)
        if dist:
            query = query.filter(User.district.ilike(f'%{dist}%'))
        if upa:
            query = query.filter(User.upazila.ilike(f'%{upa}%'))
        if age_min:
            query = query.filter(User.age >= age_min)
        
        users = query.order_by(User.created_at.desc()).all()
        return render_template('donors.html', users=users)
    except Exception as e:
        app.logger.error(f"Donors search error: {e}")
        flash("Search failed.", "danger")
        return render_template('donors.html', users=[])

@app.route('/profile/view/<int:user_id>')
def view_profile(user_id):
    try:
        user = User.query.get_or_404(user_id)
        return render_template('profile_view.html', user=user)
    except:
        abort(404)

@app.route('/profile/my')
@login_required
def my_profile():
    return render_template('my_profile.html')

@app.route('/profile/edit', methods=['GET', 'POST'])
@login_required
def edit_profile():
    if request.method == 'POST':
        try:
            current_user.name = request.form['name']
            current_user.phone = request.form['phone']
            current_user.address_holding = request.form.get('holding')
            current_user.age = request.form.get('age')
            current_user.birth_certificate_number = request.form.get('birth_certificate')
            
            # Update date of birth and recalculate age
            dob_str = request.form.get('date_of_birth')
            if dob_str:
                try:
                    current_user.date_of_birth = datetime.strptime(dob_str, '%Y-%m-%d').date()
                    today = datetime.today()
                    current_user.age = today.year - current_user.date_of_birth.year - ((today.month, today.day) < (current_user.date_of_birth.month, current_user.date_of_birth.day))
                except:
                    pass
            
            if 'profile_pic' in request.files:
                file = request.files['profile_pic']
                if file and file.filename != '' and allowed_file(file.filename):
                    filename = secure_filename(file.filename)
                    filename = datetime.now().strftime("%Y%m%d%H%M%S") + "_" + filename
                    file.save(os.path.join(app.config['UPLOAD_FOLDER'], filename))
                    current_user.image_file = filename
            
            db.session.commit()
            flash("Profile updated successfully!", "success")
            return redirect(url_for('my_profile'))
        except Exception as e:
            db.session.rollback()
            flash("Update failed. Please try again.", "danger")
            
    return render_template('edit.html')

@app.route('/toggle_status', methods=['POST'])
@login_required
def toggle_status():
    try:
        current_user.can_donate = not current_user.can_donate
        db.session.commit()
        status = 'Available' if current_user.can_donate else 'Unavailable'
        flash(f"Donation status updated: {status}", "success")
    except:
        db.session.rollback()
        flash("Status update failed.", "danger")
    return redirect(request.referrer or url_for('my_profile'))

@app.route('/apply-for-verification', methods=['POST'])
@login_required
def apply_verification():
    """User applies for donor verification (admin approves)"""
    try:
        if current_user.age and current_user.age >= 18:
            # Mark for admin review
            flash("Verification request submitted. Admin will review within 24 hours.", "info")
            return redirect(url_for('my_profile'))
        else:
            flash("You must be 18+ years old to apply for donor verification.", "warning")
            return redirect(url_for('edit_profile'))
    except Exception as e:
        app.logger.error(f"Verification error: {e}")
        flash("Failed to submit verification request.", "danger")
        return redirect(url_for('my_profile'))

# ==================== MESSAGING ROUTES ====================

@app.route('/messages')
@login_required
def messages():
    try:
        received = Message.query.filter(
            ((Message.recipient_id == current_user.id) | (Message.recipient_id == None)) & 
            (Message.is_admin_message == False)
        ).order_by(Message.created_at.desc()).all()
        
        sent = Message.query.filter_by(sender_id=current_user.id).order_by(Message.created_at.desc()).all()
        unread_count = Message.query.filter_by(recipient_id=current_user.id, is_read=False).count()
        
        return render_template('messages.html', received=received, sent=sent, unread_count=unread_count)
    except Exception as e:
        app.logger.error(f"Messages error: {e}")
        flash("Failed to load messages.", "danger")
        return redirect(url_for('home'))

@app.route('/message/send', methods=['GET', 'POST'])
@login_required
def send_message():
    if request.method == 'POST':
        try:
            subject = request.form.get('subject')
            content = request.form.get('content')
            recipient_email = request.form.get('recipient_email')
            
            if recipient_email:
                recipient = User.query.filter_by(email=recipient_email).first()
                if not recipient:
                    flash('Recipient not found.', 'danger')
                    return redirect(url_for('send_message'))
                recipient_id = recipient.id
                is_admin = False
            else:
                recipient_id = None
                is_admin = True
            
            message = Message(
                sender_id=current_user.id,
                recipient_id=recipient_id,
                subject=subject,
                content=content,
                is_admin_message=is_admin
            )
            
            db.session.add(message)
            db.session.commit()
            flash('Message sent successfully!', 'success')
            return redirect(url_for('messages'))
        except Exception as e:
            db.session.rollback()
            app.logger.error(f"Send message error: {e}")
            flash('Failed to send message.', 'danger')
            return redirect(url_for('send_message'))
    
    return render_template('send_message.html')

@app.route('/message/read/<int:message_id>')
@login_required
def read_message(message_id):
    try:
        message = Message.query.get_or_404(message_id)
        if message.recipient_id == current_user.id or message.recipient_id is None:
            message.is_read = True
            db.session.commit()
        return render_template('read_message.html', message=message)
    except Exception as e:
        app.logger.error(f"Read message error: {e}")
        abort(404)

@app.route('/message/reply/<int:message_id>', methods=['GET', 'POST'])
@login_required
def reply_message(message_id):
    try:
        original = Message.query.get_or_404(message_id)
        if request.method == 'POST':
            content = request.form.get('content')
            reply = Message(
                sender_id=current_user.id,
                recipient_id=original.sender_id,
                subject=f"Re: {original.subject}",
                content=content,
                replied_to=original.id
            )
            db.session.add(reply)
            db.session.commit()
            flash('Reply sent!', 'success')
            return redirect(url_for('messages'))
        return render_template('reply_message.html', original=original)
    except Exception as e:
        db.session.rollback()
        app.logger.error(f"Reply message error: {e}")
        flash('Failed to send reply.', 'danger')
        return redirect(url_for('messages'))

@app.route('/admin/messages')
@admin_required
def admin_messages():
    try:
        messages = Message.query.filter(
            (Message.recipient_id == None) | (Message.is_admin_message == True)
        ).order_by(Message.created_at.desc()).all()
        unread = Message.query.filter_by(recipient_id=None, is_read=False).count()
        return render_template('admin_messages.html', messages=messages, unread=unread)
    except Exception as e:
        app.logger.error(f"Admin messages error: {e}")
        flash("Failed to load messages.", "danger")
        return redirect(url_for('admin_dashboard'))

@app.route('/admin/message/reply/<int:message_id>', methods=['GET', 'POST'])
@admin_required
def admin_reply_message(message_id):
    try:
        original = Message.query.get_or_404(message_id)
        if request.method == 'POST':
            content = request.form.get('content')
            reply = Message(
                sender_id=current_user.id,
                recipient_id=original.sender_id,
                subject=f"Re: {original.subject}",
                content=content,
                replied_to=original.id,
                is_admin_message=True
            )
            db.session.add(reply)
            db.session.commit()
            flash('Reply sent to user!', 'success')
            return redirect(url_for('admin_messages'))
        return render_template('admin_reply_message.html', original=original)
    except Exception as e:
        db.session.rollback()
        app.logger.error(f"Admin reply error: {e}")
        flash('Failed to send reply.', 'danger')
        return redirect(url_for('admin_messages'))

# ==================== AUTH ROUTES ====================

@app.route('/register', methods=['GET', 'POST'])
def register():
    if current_user.is_authenticated:
        return redirect(url_for('home'))
    
    if request.method == 'POST':
        try:
            email = request.form.get('email')
            if User.query.filter_by(email=email).first():
                flash('Email already registered.', 'danger')
                return redirect(url_for('register'))
            
            filename = 'default.jpg'
            if 'profile_pic' in request.files:
                file = request.files['profile_pic']
                if file and file.filename != '' and allowed_file(file.filename):
                    filename = secure_filename(file.filename)
                    filename = datetime.now().strftime("%Y%m%d%H%M%S") + "_" + filename
                    file.save(os.path.join(app.config['UPLOAD_FOLDER'], filename))

            is_first_user = User.query.count() == 0
            
            # Calculate age from date of birth
            age = None
            date_of_birth = None
            dob_str = request.form.get('date_of_birth')
            if dob_str:
                try:
                    date_of_birth = datetime.strptime(dob_str, '%Y-%m-%d').date()
                    today = datetime.today()
                    age = today.year - date_of_birth.year - ((today.month, today.day) < (date_of_birth.month, date_of_birth.day))
                except:
                    age = request.form.get('age')
                    if age:
                        age = int(age)
            else:
                age = request.form.get('age')
                if age:
                    age = int(age)

            user = User(
                name=request.form.get('name'),
                email=email,
                phone=request.form.get('phone'),
                blood_group=request.form.get('blood_group'),
                role=request.form.get('role'),
                division=request.form.get('division'),
                district=request.form.get('district'),
                upazila=request.form.get('upazila'),
                union=request.form.get('union'),
                address_holding=request.form.get('holding'),
                image_file=filename,
                is_super_admin=is_first_user,
                is_admin=is_first_user,
                age=age,
                date_of_birth=date_of_birth,
                birth_certificate_number=request.form.get('birth_certificate'),  # Optional
                is_verified=False  # New users not verified by default
            )
            user.set_password(request.form.get('password'))
            db.session.add(user)
            db.session.commit()
            login_user(user)
            flash('Registration successful! Complete your profile to start donating.', 'success')
            return redirect(url_for('home'))
        except Exception as e:
            db.session.rollback()
            app.logger.error(f"Registration error: {e}")
            flash('Registration failed. Please try again.', 'danger')
            return redirect(url_for('register'))

    return render_template('register.html')

@app.route('/login', methods=['GET', 'POST'])
def login():
    if current_user.is_authenticated:
        return redirect(url_for('home'))
    
    if request.method == 'POST':
        try:
            user = User.query.filter_by(email=request.form.get('email')).first()
            if user and user.check_password(request.form.get('password')):
                login_user(user)
                next_page = request.args.get('next')
                return redirect(next_page or url_for('home'))
            flash('Login failed. Check email/password.', 'danger')
        except Exception as e:
            app.logger.error(f"Login error: {e}")
            flash('Login error. Please try again.', 'danger')
    return render_template('login.html')

@app.route('/logout')
@login_required
def logout():
    logout_user()
    flash('You have been logged out.', 'info')
    return redirect(url_for('home'))

# ==================== OTHER ROUTES ====================

@app.route('/compatibility')
def compatibility():
    return render_template('compat.html')

@app.route('/antid')
def antid():
    try:
        antid_info = AntiDInfo.query.all()
    except:
        antid_info = []
    return render_template('antid.html', antid_info=antid_info)

@app.route('/resources')
def resources():
    """Educational resources page like Badhan.org"""
    try:
        category = request.args.get('category')
        query = Resource.query
        if category:
            query = query.filter_by(category=category)
        resources = query.order_by(Resource.is_featured.desc(), Resource.created_at.desc()).all()
        return render_template('resources.html', resources=resources)
    except:
        return render_template('resources.html', resources=[])

@app.route('/admin')
@admin_required
def admin_dashboard():
    try:
        users = User.query.order_by(User.created_at.desc()).all()
        total_users = User.query.count()
        total_donors = User.query.filter_by(can_donate=True, is_verified=True).count()
        admins = User.query.filter_by(is_admin=True).count()
        unread_messages = Message.query.filter_by(recipient_id=None, is_read=False).count()
        pending_verifications = User.query.filter_by(is_verified=False, age>=18).count()
        urgent_requests = BloodRequest.query.filter_by(is_urgent=True, is_fulfilled=False).count()
        
        stats = {
            'total_users': total_users,
            'total_donors': total_donors,
            'admins': admins,
            'unread_messages': unread_messages,
            'pending_verifications': pending_verifications,
            'urgent_requests': urgent_requests
        }
        
        notice = SiteNotice.query.first()
        curr_note = notice.content if notice else ""
        
        return render_template('admin.html', all_users=users, stats=stats, current_notice=curr_note)
    except Exception as e:
        app.logger.error(f"Admin dashboard error: {e}")
        flash("Dashboard failed to load.", "danger")
        return redirect(url_for('home'))

@app.route('/admin/verify-donor/<int:user_id>', methods=['POST'])
@admin_required
def verify_donor(user_id):
    """Admin verifies a donor (18+ eligible)"""
    try:
        user = User.query.get_or_404(user_id)
        if user.age and user.age >= 18:
            user.is_verified = True
            db.session.commit()
            flash(f"{user.name} is now a verified donor!", "success")
        else:
            flash("User must be 18+ to be verified as donor.", "warning")
        return redirect(url_for('admin_dashboard'))
    except Exception as e:
        db.session.rollback()
        flash("Verification failed.", "danger")
        return redirect(url_for('admin_dashboard'))

@app.route('/admin/promote/<int:user_id>')
@admin_required
def admin_promote(user_id):
    if not current_user.is_super_admin:
        flash("Only Super Admin can promote admins.", "warning")
        return redirect(url_for('admin_dashboard'))
    try:
        user = User.query.get_or_404(user_id)
        user.is_admin = True
        db.session.commit()
        flash(f"{user.name} is now an Admin.", "success")
    except:
        db.session.rollback()
        flash("Promotion failed.", "danger")
    return redirect(url_for('admin_dashboard'))

@app.route('/admin/demote/<int:user_id>')
@admin_required
def admin_demote(user_id):
    if not current_user.is_super_admin:
        flash("Unauthorized.", "danger")
        return redirect(url_for('admin_dashboard'))
    try:
        user = User.query.get_or_404(user_id)
        if user.is_super_admin:
            flash("Cannot demote Super Admin.", "warning")
            return redirect(url_for('admin_dashboard'))
        user.is_admin = False
        db.session.commit()
        flash(f"Admin rights removed from {user.name}.", "info")
    except:
        db.session.rollback()
        flash("Demotion failed.", "danger")
    return redirect(url_for('admin_dashboard'))

@app.route('/admin/delete/<int:user_id>')
@admin_required
def admin_delete_user(user_id):
    if not current_user.is_super_admin:
        flash("Unauthorized.", "danger")
        return redirect(url_for('admin_dashboard'))
    try:
        user = User.query.get_or_404(user_id)
        if user.is_super_admin:
            flash("Cannot delete Super Admin.", "warning")
            return redirect(url_for('admin_dashboard'))
        if user.id == current_user.id:
            flash("Cannot delete your own account.", "warning")
            return redirect(url_for('admin_dashboard'))
        db.session.delete(user)
        db.session.commit()
        flash("User deleted successfully.", "danger")
    except:
        db.session.rollback()
        flash("Deletion failed.", "danger")
    return redirect(url_for('admin_dashboard'))

@app.route('/admin/notice', methods=['POST'])
@admin_required
def update_notice():
    try:
        content = request.form.get('notice_content', '').strip()
        if not content:
            flash("Notice cannot be empty.", "warning")
            return redirect(url_for('admin_dashboard'))
        notice = SiteNotice.query.first()
        if not notice:
            notice = SiteNotice(content=content)
            db.session.add(notice)
        else:
            notice.content = content
        db.session.commit()
        flash("Site notice updated.", "success")
    except:
        db.session.rollback()
        flash("Notice update failed.", "danger")
    return redirect(url_for('admin_dashboard'))

@app.route('/admin/notice/clear')
@admin_required
def clear_notice():
    try:
        notice = SiteNotice.query.first()
        if notice:
            db.session.delete(notice)
            db.session.commit()
            flash("Notice cleared.", "info")
    except:
        db.session.rollback()
        flash("Clear failed.", "danger")
    return redirect(url_for('admin_dashboard'))

@app.route('/health')
def health_check():
    try:
        db.session.execute('SELECT 1')
        return {'status': 'healthy', 'database': 'connected'}, 200
    except Exception as e:
        return {'status': 'unhealthy', 'error': str(e)}, 500

# ==================== DATABASE INIT ====================

with app.app_context():
    try:
        db.create_all()
        # Add default Anti-D info if none exists
        if AntiDInfo.query.count() == 0:
            default_antid = AntiDInfo(
                title="Anti-D Immunoglobulin Injection",
                description="Anti-D injection is given to Rh-negative mothers to prevent Rh incompatibility issues during pregnancy.",
                timing="28 weeks of pregnancy and within 72 hours after delivery",
                dosage="300 mcg (1500 IU) intramuscular injection"
            )
            db.session.add(default_antid)
            db.session.commit()
        # Add sample resources
        if Resource.query.count() == 0:
            resources = [
                Resource(title="Why Donate Blood?", category="Donation", content="Blood donation saves lives. One donation can help up to 3 people.", is_featured=True),
                Resource(title="Blood Donation Process", category="Donation", content="Step-by-step guide to donating blood safely.", is_featured=True),
                Resource(title="First Aid Basics", category="First-Aid", content="Essential first aid knowledge for emergencies."),
                Resource(title="Healthy Lifestyle", category="Health", content="Tips for maintaining good health as a donor."),
            ]
            db.session.add_all(resources)
            db.session.commit()
    except Exception as e:
        app.logger.error(f"Database initialization error: {e}")

application = app

if __name__ == '__main__':
    app.run(debug=False)